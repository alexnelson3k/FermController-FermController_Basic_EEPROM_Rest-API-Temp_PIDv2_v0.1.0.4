#include "Param_types.h"

ConfigParam system_params[PARAM_COUNT] = {
    // System
    [PARAM_VERSION] = {
        "version", "Config version", TYPE_UINT8, 
		SERIAL_MENU | DISPLAY_ACCESS | API_ACCESS,
        {.uint8 = {1, 1, 255, 1, 1}}
    },

    [PARAM_UPTIME] = {
        "uptime", "Uptime", TYPE_STRING,
		SERIAL_MENU | DISPLAY_ACCESS | API_ACCESS | NO_FLASH_SAVE,
        {.string = {"", 12, ""}}
    },
    
    [PARAM_POWER_LEVEL] = {
        "power_level", "Manual power level (%)", TYPE_UINT8, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {.uint8 = {0, 0, 100, 1, 0}}
    },
    
    // Temperature Configuration
    [PARAM_TEMP_SETPOINT] = {
        "temp_setpoint", "Temperature setpoint", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {25.0, 0.0, 100.0, 1.0, 25.0}
    },
    
    [PARAM_TEMP_SETPOINT_MIN] = {
        "temp_setpoint_min", "Min temperature setpoint", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {0.0, 0.0, 50.0, 0.1, 0.0}  // TEMP_SETPOINT_MIN
    },
    
    [PARAM_TEMP_SETPOINT_MAX] = {
        "temp_setpoint_max", "Max temperature setpoint", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {100.0, 50.0, 100.0, 0.1, 100.0}  // TEMP_SETPOINT_MAX
    },
    
    [PARAM_TEMP_HYSTERESIS] = {
        "temp_hysteresis", "Temperature hysteresis", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {0.5, 0.1, 5.0, 0.1, 0.5}  // TEMP_HYSTERESIS
    },
    
    [PARAM_CURRENT_TEMP] = {
        "current_temp", "Current temperature", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | API_ACCESS | NO_FLASH_SAVE,
        {0.0, -50.0, 150.0, 0.1, 0.0}
    },
    
    [PARAM_TEMP_CALIBRATION] = {
        "temp_calibration", "Temperature calibration", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {0.0, -10.0, 10.0, 0.1, 0.0}
    },
    
    [PARAM_TEMP_SENSOR_TYPE] = {
        "temp_sensor_type", "Temperature sensor type", TYPE_UINT8, 
        SERIAL_MENU | DISPLAY_ACCESS | API_ACCESS,
        {.uint8 = {0, 0, 2, 1, 0}}  // 0=DS18B20, 1=DHT22, 2=NTC
    },
    
    [PARAM_UPDATE_INTERVAL] = {
        "Sensors update_interval", "Sensors update interval (ms)", TYPE_FLOAT,
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {1000.0, 100.0, 10000.0, 100.0, 1000.0}
    },
	[PARAM_HEATER_ENABLED] = {
        "heater_enabled", "Heater enabled", TYPE_BOOL,
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS | NO_FLASH_SAVE,
        {.boolean = {true, true}}  // value=true, default=true
    },

    // PID Configuration (перенесено из config.h)
    [PARAM_PID_KP] = {
        "pid_kp", "PID proportional gain", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {2.0, 0.0, 100.0, 0.1, 2.0}
    },
    
    [PARAM_PID_KI] = {
        "pid_ki", "PID integral gain", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {0.5, 0.0, 10.0, 0.01, 0.5}
    },
    
    [PARAM_PID_KD] = {
        "pid_kd", "PID derivative gain", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {1.0, 0.0, 10.0, 0.1, 1.0}
    },
    
    [PARAM_PID_SAMPLE_TIME] = {
        "pid_sample_time", "PID sample time (ms)", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {1000.0, 100.0, 10000.0, 100.0, 1000.0}  // PID_SAMPLE_TIME
    },
    
    [PARAM_PID_MAX_POWER] = {
        "pid_max_power", "PID maximum power (%)", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {80.0, 0.0, 100.0, 1.0, 80.0}  // PID_MAX_POWER
    },
    
    [PARAM_PID_MIN_POWER] = {
        "pid_min_power", "PID minimum power (%)", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {0.0, 0.0, 100.0, 1.0, 0.0}  // PID_MIN_POWER
    },
    
    [PARAM_PID_MAX_TEMP_DIFF] = {
        "pid_max_temp_diff", "PID maximum temperature difference", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {5.0, 0.1, 20.0, 0.1, 5.0}  // PID_MAX_TEMP_DIFF
    },
    
    [PARAM_PID_MIN_TEMP_DIFF] = {
        "pid_min_temp_diff", "PID minimum temperature difference", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {1.0, 0.1, 10.0, 0.1, 1.0}  // PID_MIN_TEMP_DIFF
    },
    
    [PARAM_PID_SWITCHING_DELTA] = {
        "pid_switching_delta", "PID switching delta", TYPE_FLOAT, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {5.0, 0.1, 10.0, 0.1, 5.0}  // PID_SWITCHING_DELTA
    },
    
    [PARAM_HEATER_RUNNING] = {
        "heater_running", "Heater running", TYPE_BOOL, 
        SERIAL_MENU | DISPLAY_ACCESS | API_ACCESS | NO_FLASH_SAVE,
        {.boolean = {false, false}}
    },
	
	    [PARAM_OPERATING_MODE] = {
        "operating_mode", "Operating mode (0=Manual, 1=Auto)", TYPE_UINT8, 
        SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {.uint8 = {1, 0, 1, 1, 1}}  // value=1, min=0, max=1, step=1, default=1 (Auto)
    },	
    
    // Network settings (перенесено из ConfigData)
    [PARAM_WIFI_SSID] = {
        "wifi_ssid", "WiFi SSID", TYPE_STRING,
		SERIAL_MENU | DISPLAY_ACCESS | API_ACCESS,
        {.string = {"wifi", 32, "wifi"}}
    },
    
    [PARAM_WIFI_PASSWORD] = {
        "wifi_password", "WiFi password", TYPE_STRING,
		SERIAL_MENU | API_ACCESS| SECURED_VALUE,
        {.string = {"passw", 64, "passw"}}
    },
    
    [PARAM_MQTT_SERVER] = {
        "mqtt_server", "MQTT server", TYPE_STRING,
		SERIAL_MENU | DISPLAY_ACCESS | API_ACCESS,
        {.string = {"", 64, ""}}
    },
    
    [PARAM_MQTT_PORT] = {
        "mqtt_port", "MQTT port", TYPE_UINT16,
		SERIAL_MENU | DISPLAY_ACCESS | API_ACCESS,
        {.uint16 = {1883, 1, 65535, 1, 1883}}
    },
    
    [PARAM_API_TOKEN] = {
        "api_token", "API token", TYPE_STRING,
		SERIAL_MENU | API_ACCESS| SECURED_VALUE,
        {.string = {"my_token-102938", 33, "my_token-102938"}}
    },
    
    [PARAM_HTTPS_ENABLED] = {
        "https_enabled", "HTTPS enabled", TYPE_BOOL,
		SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {.boolean = {true, true}}
    },
    
    [PARAM_HTTPS_PORT] = {
        "https_port", "HTTPS port", TYPE_UINT16,
		SERIAL_MENU | DISPLAY_ACCESS | ROTARY_ACCESS | API_ACCESS,
        {.uint16 = {443, 1, 65535, 1, 443}}
    },

    // NTP Configuration
    [PARAM_NTP_SERVER] = {
        "ntp_server", "NTP server", TYPE_STRING,
        SERIAL_MENU | API_ACCESS | DISPLAY_ACCESS,
        {.string = {"time.google.com", 64, "time.google.com"}}
    },

    [PARAM_NTP_GMT_OFFSET] = {
        "ntp_gmt_offset", "GMT offset (hours)", TYPE_INT16,
        SERIAL_MENU | API_ACCESS | DISPLAY_ACCESS,
        {.int16 = {0, -12, 12, 1, 0}}  // -12 to +12 hours
    },

    [PARAM_NTP_DAYLIGHT_OFFSET] = {
        "ntp_daylight_offset", "Daylight offset (hours)", TYPE_INT16, 
        SERIAL_MENU | API_ACCESS | DISPLAY_ACCESS,
        {.int16 = {1, 0, 2, 1, 1}}  // 0 to 2 hours
    }

};